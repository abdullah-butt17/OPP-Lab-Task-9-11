from File_01 import Employee
class Worker(Employee):
    def __init__(self, name, age, salary,hour_worked):
        super().__init__(name, age, salary)
        self.__hour_worked=hour_worked
    def get_hour_worked(self):
        return self.__hour_worked
    def set_hour_worked(self,hour_worked):
        self.__hour_worked=hour_worked
    def display_info(self):
        super().display_info()
        print("Hour Worked:",self.__hour_worked)
    def to_dic(self):
        data=super().to_dic()
        data["Hour Worked"]= self.__hour_worked
        return data